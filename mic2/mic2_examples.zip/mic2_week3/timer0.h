/*
  MIC2 Week 3. Timers/Counters

  Author <Student name>
         <Student number>
  Date   dd/mm/yyyy
*/
#ifndef TIMER0_H
#define TIMER0_H

#include <stdint.h>

void timer0_init(void);
uint32_t timer0_millis(void);

#endif  // TIMER0_H
